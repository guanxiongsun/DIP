// hilbertView.cpp : implementation of the CHilbertView class
//

#include "stdafx.h"
#include "hilbert.h"

#include "hilbertDoc.h"
#include "hilbertView.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHilbertView

IMPLEMENT_DYNCREATE(CHilbertView, CFormView)

BEGIN_MESSAGE_MAP(CHilbertView, CFormView)
	//{{AFX_MSG_MAP(CHilbertView)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHilbertView construction/destruction

CHilbertView::CHilbertView()
	: CFormView(CHilbertView::IDD)
{
	//{{AFX_DATA_INIT(CHilbertView)
	m_stage = 1;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CHilbertView::~CHilbertView()
{
}

void CHilbertView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHilbertView)
	DDX_Control(pDX, IDC_SPIN2, m_spin);
	DDX_Text(pDX, IDC_EDIT1, m_stage);
	DDV_MinMaxUInt(pDX, m_stage, 1, 7);
	//}}AFX_DATA_MAP
}

BOOL CHilbertView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CHilbertView diagnostics

#ifdef _DEBUG
void CHilbertView::AssertValid() const
{
	CFormView::AssertValid();
}

void CHilbertView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CHilbertDoc* CHilbertView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CHilbertDoc)));
	return (CHilbertDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CHilbertView message handlers

#define TURNLEFT    1
#define TURNRIGHT  -1
UINT g_step;
POINT g_position;
POINT g_direction;
CDC * g_pDC;
void TurnDirection(int direction);
void DrawHilbert(UINT stage, int LeftOrRight);

void CHilbertView::OnDraw(CDC* pDC) 
{
	// TODO: Add your specialized code here and/or call the base class
	g_pDC = pDC;
	RECT rc;
	GetClientRect(&rc);
	g_position.x = (int)(rc.right*0.618);
	g_position.y = rc.bottom/6;
	g_step = rc.bottom*5/(6*(int)pow(2, m_stage));
	pDC->MoveTo(g_position);	
	if(m_stage%2 == 0)
	{
		g_direction.x = 0; 
		g_direction.y = 1;
	}
	else
	{
		g_direction.x = -1; 
		g_direction.y = 0;
	}
	DrawHilbert(m_stage, TURNLEFT);
	
}

void TurnDirection(int direction)
{
	int x = g_direction.x;
	int y = g_direction.y;

	g_direction.x = direction*y;
	g_direction.y = -direction*x;
}

void DrawHilbert(UINT stage, int LeftOrRight)
{
	if(stage == 1)
	{
		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
		TurnDirection(LeftOrRight);

		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
		TurnDirection(LeftOrRight);

		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
	}
	else
	{
		DrawHilbert( stage-1, -LeftOrRight);
		
		if( stage%2 == 0 )
			TurnDirection(LeftOrRight);
		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
		if( stage%2 != 0 )
			TurnDirection(LeftOrRight);

		DrawHilbert( stage-1, LeftOrRight);

		if( stage%2 == 0 )
			TurnDirection(-LeftOrRight);
		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
		if( stage%2 == 0 )
			TurnDirection(-LeftOrRight);

		DrawHilbert( stage-1, LeftOrRight);

		if( stage%2 != 0 )
			TurnDirection(LeftOrRight);
		g_position.x += g_step*g_direction.x;
		g_position.y += g_step*g_direction.y;
		g_pDC->LineTo(g_position);
		if( stage%2 == 0 )
			TurnDirection(LeftOrRight);

		DrawHilbert( stage-1, -LeftOrRight);

	}
}

void CHilbertView::OnChangeEdit1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CFormView::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_stage>=1 && m_stage<=7)
		Invalidate();
}

void CHilbertView::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	m_spin.SetRange(1, 7);
	m_spin.SetPos(m_stage);
	m_spin.SetBuddy(GetDlgItem( IDC_EDIT1 ));
}
