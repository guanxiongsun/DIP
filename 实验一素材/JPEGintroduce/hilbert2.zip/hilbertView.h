// hilbertView.h : interface of the CHilbertView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_HILBERTVIEW_H__E68D56C0_2437_11D3_A050_B0B907C1B3EF__INCLUDED_)
#define AFX_HILBERTVIEW_H__E68D56C0_2437_11D3_A050_B0B907C1B3EF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CHilbertView : public CFormView
{
protected: // create from serialization only
	CHilbertView();
	DECLARE_DYNCREATE(CHilbertView)

public:
	//{{AFX_DATA(CHilbertView)
	enum { IDD = IDD_HILBERT_FORM };
	CSpinButtonCtrl	m_spin;
	UINT	m_stage;
	//}}AFX_DATA

// Attributes
public:
	CHilbertDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHilbertView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHilbertView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CHilbertView)
	afx_msg void OnChangeEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in hilbertView.cpp
inline CHilbertDoc* CHilbertView::GetDocument()
   { return (CHilbertDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HILBERTVIEW_H__E68D56C0_2437_11D3_A050_B0B907C1B3EF__INCLUDED_)
